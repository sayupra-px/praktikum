package com.example.praktikumuiux_7020230044

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
