class Product {
  final String name;
  final String price;
  final String image;
  final String description;

  Product({
    required this.name,
    required this.price,
    required this.image,
    required this.description,
  });
}

// Data dummy untuk ditampilkan di UI
List<Product> dummyProducts = [
  Product(
    name: "Kulkas 2 Pintu SBS 550 Liter",
    price: "Rp 8.259.000",
    image: "assets/kulkasSBS.jpg",
    description: 'Kulkas ini memiliki Inverter Technology, Frezeer Quick, Cooling Compratment, Digital Temp, dan Deodorizer memiliki Garansi Kompresor 10 tahun',
  ),
  Product(
    name: "Kulkas 2 Pintu Flexup 260 Liter",
    price: "Rp 3.689.000",
    image: "assets/kulkasdlexup.jpg",
    description: 'Kulkas 2 pintu dengan fitur 5in1 Cooling System, tidak hanya menyediakan ruang Freezer Compartment, tetapi juga dapat diubah menjadi Fridge, Chiller atau Freezer sesuai kebutuhan.'
  ),
  Product(
    name: "Mesin Cuci Top Loading 10Kg",
    price: "Rp 2.979.000",
    image: "assets/mesincuciTop.jpg",
    description: 'Teknologi Ultra Clean program pencucian khusus dengan 2 tahap pencucian, terbukti 100% menghilangkan noda membandel seperti kecap, obat merah, minyak, cokelat, sirup dan noda membandel lainnya.'
  ),
  Product(
    name: "AC Smart Neuva Pro 1/2 Pk",
    price: "2.839.000",
    image: "assets/acsmart.jpg",
    description: 'C Smart Neuva Pro Polytron memberikan solusi dengan pendinginan yang ekstrim cepat dan lebih Hemat Energi. Hal ini dicapai melalui desain High Efficiency Cooling Engine. Proses pendinginan yang ekstrim cepat (25% lebih cepat dari AC biasa*), memberikan manfaat besar di saat cuaca panas sekali.'
  ),
  Product(
    name: "Laptop Luxia i3",
    price: "Rp 5.799.000",
    image: "assets/luxia3.jpg",
    description: 'Dirancang untuk kamu yang aktif dan stylish, laptop ini hadir dengan cover metal berwarna Obsidian Gray yang kokoh dan elegan. Dilengkapi port Type-C, siap mendukung mobilitasmu dari kelas pagi, meeting siang, hingga me time malam tanpa hambatan.'
  ),
  Product(
    name: "Laptop Luxia Pro i5",
    price: "Rp 8.429.000",
    image: "assets/luxiaproi5.jpg",
    description: 'Enteng banget! Dengan bobot kurang dari 1 kg dan material magnesium , dan warna Titanium Gray yang premium. Laptop ini dirancang ultralight tanpa mengorbankan kekuatan dan kualitas. Ideal untuk mobilitas tinggi dengan tampilan elegan.'
  ),
];